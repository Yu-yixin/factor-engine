# 因子表达式引擎

Factor Engine 是一个基于 Python + Polars 的因子表达式计算原型系统，用来把表达式字符串解析、校验并执行成 DataFrame 结果。

## What This Engine Is

这个引擎面向研究型工作流，重点解决三件事：

- 把 DSL 表达式解析成可执行内部表示
- 在执行前做语义校验
- 在 Polars DataFrame 上执行 pointwise、cross-sectional、time-series、segmented 和 table 表达式

`README` 只保留入口信息。完整语言语义、函数规则、工作流和错误系统已经拆到 `docs/` 下的专门文档。

## What You Can Do

- 写逐点表达式：`close - open`
- 写截面表达式：`demean(close)`、`group_rank(close, industry, pct=true)`
- 写时序表达式：`delta(close, 1)`、`ts_rank(close, 20, pct=true)`
- 写分段表达式：`seg_mean(close, 3)`、`seglen_sum(close, [3, 5, 2])`
- 写组合表达式：`where(not is_null(close), clip(ts_mean(close, 5), 0, 100), 0)`
- 跑单表达式或批量表达式
- 从 YAML / JSON 文件加载表达式批次并把结果写到 parquet / csv

## 安装

建议使用 Python `3.10+`。

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
py -m pip install polars pytest ruff
```

## Quick Example

```python
import polars as pl

from factor_engine.engine import FactorEngine

df = pl.DataFrame(
    {
        "time": [1, 2, 3],
        "code": ["A", "A", "A"],
        "close": [10.0, 20.0, 30.0],
        "open": [9.0, 18.0, 29.0],
    }
)

engine = FactorEngine()

single = engine.evaluate("delta(close, 1)", df)
batch = engine.evaluate_many(
    [
        ("spread", "close - open"),
        ("ts_rank_3", "ts_rank(close, 3, pct=true)"),
    ],
    df,
)

print(single)
print(batch)
```

组合表达式示例：

```text
where(not is_null(close), clip(ts_mean(close, 5), 0, 100), 0)
```

文件工作流示例入口：

```powershell
$env:PYTHONPATH="src"
py examples/file_batch_workflow.py input.parquet expressions.yaml --output result.parquet
```

## Core Concepts

- `pointwise`
  - 逐行计算，不依赖分组排序
- `cross-sectional`
  - 按 `time` 分组
- `grouped cross-sectional`
  - 按 `[time, group_col]` 分组
- `time-series`
  - 按 `code` 分组、按 `time` 排序
- `segmented`
  - 仍走 time-series 路径，但把每个 `code` 序列切成段后再聚合
- `table`
  - 返回新表；当前是 `fft(...)`

## Public API

核心入口仍然是 `FactorEngine`：

- `parse(expression)`
- `validate(expression, df)`
- `evaluate(expression, df, output_name="result")`
- `evaluate_many(expressions, df)`

## Docs Navigation

- [docs/index.md](docs/index.md)
  - 文档总导航与阅读顺序
- [docs/language.md](docs/language.md)
  - DSL 语法、表达式类型、运算符优先级、逻辑与 null 规则
- [docs/functions.md](docs/functions.md)
  - 全量函数参考，包括 `ts_median`、`argmax / argmin`、`group_*`、`seglen_*`
- [docs/workflow.md](docs/workflow.md)
  - YAML / JSON 批量输入、严格模式、continue-on-error、结果写出
- [docs/errors.md](docs/errors.md)
  - 错误类型、错误阶段、失败载荷、批量报告格式
- [docs/design.md](docs/design.md)
  - 当前代码结构与模块边界
- [docs/execution_planning_optimization.md](docs/execution_planning_optimization.md)
  - 执行规划、批量执行与缓存复用
- [docs/benchmark.md](docs/benchmark.md)
  - benchmark 口径与结果落点
- [docs/documentation_policy.md](docs/documentation_policy.md)
  - 文档治理与再次优化条件
- [docs/revolution.md](docs/revolution.md)
  - 演进记录与阶段性决策

## 开发与验证

运行全部测试：

```powershell
$env:PYTHONPATH="src"
py -m pytest
```

运行静态检查：

```powershell
.venv\Scripts\python -m ruff check
```

运行 demo：

```powershell
$env:PYTHONPATH="src"
py examples/demo.py
```

## 当前边界

- 当前不支持字符串字面量
- `evaluate_many()` 只接受列级表达式
- workflow 文件输入当前只支持固定 YAML / JSON schema
- 当前缓存只覆盖编译层，不覆盖整列执行结果
- 若表达式要用于下一期交易决策，通常应显式滞后，例如 `delay(signal, 1)`
