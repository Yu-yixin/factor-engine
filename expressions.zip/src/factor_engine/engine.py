from __future__ import annotations

from collections import OrderedDict
from collections.abc import Sequence
from dataclasses import dataclass

import polars as pl

from factor_engine.ast_nodes import (
    BinaryOpNode,
    BooleanNode,
    CallNode,
    Expr,
    ListNode,
    NumberNode,
    UnaryOpNode,
    VariableNode,
)
from factor_engine.executor import Executor
from factor_engine.errors import ArgumentError
from factor_engine.lexer import Lexer
from factor_engine.parser import Parser
from factor_engine.registry import get_function_spec
from factor_engine.validator import ValidationResult, Validator


@dataclass(frozen=True)
class _CompiledCacheKey:
    expression: str
    schema_fingerprint: tuple[tuple[str, str], ...]
    time_col: str
    code_col: str


@dataclass(frozen=True)
class _CompiledArtifacts:
    expr: Expr
    validation: ValidationResult
    compiled: pl.Expr | None = None


class _LruCache:
    def __init__(self, max_size: int):
        self.max_size = max_size
        self._entries: OrderedDict[object, object] = OrderedDict()

    def get(self, key: object) -> object | None:
        value = self._entries.get(key)
        if value is None:
            return None

        self._entries.move_to_end(key)
        return value

    def set(self, key: object, value: object) -> None:
        self._entries[key] = value
        self._entries.move_to_end(key)

        while len(self._entries) > self.max_size:
            self._entries.popitem(last=False)


def _schema_fingerprint(df: pl.DataFrame) -> tuple[tuple[str, str], ...]:
    return tuple((name, repr(dtype)) for name, dtype in df.schema.items())


def _clone_expr(expr: Expr) -> Expr:
    # The engine keeps cached AST nodes internally; cloning protects the cache
    # from accidental mutations when callers use the public parse() API.
    if isinstance(expr, NumberNode):
        return NumberNode(expr.value)
    if isinstance(expr, BooleanNode):
        return BooleanNode(expr.value)
    if isinstance(expr, ListNode):
        return ListNode(items=[_clone_expr(item) for item in expr.items])
    if isinstance(expr, VariableNode):
        return VariableNode(expr.name)
    if isinstance(expr, UnaryOpNode):
        return UnaryOpNode(operator=expr.operator, operand=_clone_expr(expr.operand))
    if isinstance(expr, BinaryOpNode):
        return BinaryOpNode(
            left=_clone_expr(expr.left),
            operator=expr.operator,
            right=_clone_expr(expr.right),
        )
    if isinstance(expr, CallNode):
        return CallNode(
            name=expr.name,
            args=[_clone_expr(arg) for arg in expr.args],
            kwargs={key: _clone_expr(value) for key, value in expr.kwargs.items()},
        )

    raise TypeError(f"Unsupported AST node for cloning: {type(expr).__name__}")


class FactorEngine:
    def __init__(
        self,
        time_col: str = "time",
        code_col: str = "code",
        cache_size: int = 256,
    ):
        if cache_size <= 0:
            raise ValueError("cache_size must be a positive integer")

        self.time_col = time_col
        self.code_col = code_col
        # Caches are instance-scoped on purpose: entries can be reused across
        # repeated evaluations, but they do not leak across engine lifecycles
        # or implicitly claim correctness for unrelated data versions.
        self._ast_cache = _LruCache(cache_size)
        self._validation_cache = _LruCache(cache_size)
        self._compiled_expr_cache = _LruCache(cache_size)

    def parse(self, expression: str):
        return _clone_expr(self._get_or_parse_ast(expression))

    def validate(self, expression: str, df: pl.DataFrame) -> ValidationResult:
        return self._get_or_validate(expression, df)

    def evaluate(
        self,
        expression: str,
        df: pl.DataFrame,
        output_name: str = "result",
    ) -> pl.DataFrame:
        artifacts = self._get_or_compile(expression, df)
        executor = Executor(
            df=df,
            time_col=self.time_col,
            code_col=self.code_col,
        )
        # Cache hits must preserve the exact execution contract; they only skip
        # redundant planning work and never change validation or runtime semantics.
        if artifacts.compiled is not None:
            return executor.evaluate_compiled(
                artifacts.compiled,
                output_name=output_name,
                validation=artifacts.validation,
            )
        return executor.evaluate(
            artifacts.expr,
            output_name=output_name,
            validation=artifacts.validation,
        )

    def evaluate_many(
        self,
        expressions: Sequence[tuple[str, str]],
        df: pl.DataFrame,
    ) -> pl.DataFrame:
        compiled_items: list[tuple[str, ValidationResult, pl.Expr]] = []
        deferred_items: list[tuple[str, Expr, ValidationResult]] = []
        seen_names: set[str] = set()

        for output_name, expression in expressions:
            if output_name in seen_names:
                raise ArgumentError(f"Duplicate output column name in evaluate_many(): {output_name}")
            seen_names.add(output_name)

            artifacts = self._get_or_compile(expression, df)
            if artifacts.validation.result_kind != "column":
                raise ArgumentError(
                    "evaluate_many() only supports column expressions in the current version"
                )
            if artifacts.compiled is None:
                deferred_items.append((output_name, artifacts.expr, artifacts.validation))
            else:
                compiled_items.append((output_name, artifacts.validation, artifacts.compiled))

        result_df = df
        if compiled_items:
            executor = Executor(
                df=result_df,
                time_col=self.time_col,
                code_col=self.code_col,
            )
            result_df = executor.evaluate_many_compiled(compiled_items)

        if deferred_items:
            result_df = Executor(
                df=result_df,
                time_col=self.time_col,
                code_col=self.code_col,
            ).evaluate_many(deferred_items)

        appended_columns = [output_name for output_name, _ in expressions if output_name not in df.columns]
        return result_df.select([*df.columns, *appended_columns])

    def _validate_expr(self, expr: Expr, df: pl.DataFrame) -> ValidationResult:
        return Validator(
            schema=df.schema,
            time_col=self.time_col,
            code_col=self.code_col,
        ).validate(expr)

    def _build_compiled_cache_key(self, expression: str, df: pl.DataFrame) -> _CompiledCacheKey:
        return _CompiledCacheKey(
            expression=expression,
            schema_fingerprint=_schema_fingerprint(df),
            time_col=self.time_col,
            code_col=self.code_col,
        )

    def _get_or_parse_ast(self, expression: str) -> Expr:
        cached = self._ast_cache.get(expression)
        if cached is not None:
            return cached

        tokens = Lexer(expression).tokenize()
        expr = Parser(tokens).parse()
        self._ast_cache.set(expression, expr)
        return expr

    def _get_or_validate(self, expression: str, df: pl.DataFrame) -> ValidationResult:
        cache_key = self._build_compiled_cache_key(expression, df)
        cached = self._validation_cache.get(cache_key)
        if cached is not None:
            return cached

        expr = self._get_or_parse_ast(expression)
        validation = self._validate_expr(expr, df)
        self._validation_cache.set(cache_key, validation)
        return validation

    def _get_or_compile(self, expression: str, df: pl.DataFrame) -> _CompiledArtifacts:
        cache_key = self._build_compiled_cache_key(expression, df)
        expr = self._get_or_parse_ast(expression)
        validation = self._get_or_validate(expression, df)

        if validation.result_kind != "column":
            return _CompiledArtifacts(expr=expr, validation=validation)

        if self._expr_uses_segmented_window(expr):
            # Segmented execution depends on executor-scoped helper columns, so v1 keeps
            # those expressions on the AST execution path instead of caching pl.Expr objects.
            return _CompiledArtifacts(expr=expr, validation=validation)

        compiled = self._compiled_expr_cache.get(cache_key)
        if compiled is None:
            compiled = Executor(
                df=df,
                time_col=self.time_col,
                code_col=self.code_col,
            ).compile(expr)
            self._compiled_expr_cache.set(cache_key, compiled)

        return _CompiledArtifacts(expr=expr, validation=validation, compiled=compiled)

    def _expr_uses_segmented_window(self, expr: Expr) -> bool:
        if isinstance(expr, CallNode):
            spec = get_function_spec(expr.name)
            if spec is not None and spec.window_kind == "segmented":
                return True
            return any(self._expr_uses_segmented_window(arg) for arg in expr.args) or any(
                self._expr_uses_segmented_window(value) for value in expr.kwargs.values()
            )

        if isinstance(expr, UnaryOpNode):
            return self._expr_uses_segmented_window(expr.operand)

        if isinstance(expr, BinaryOpNode):
            return self._expr_uses_segmented_window(expr.left) or self._expr_uses_segmented_window(
                expr.right
            )

        return False
