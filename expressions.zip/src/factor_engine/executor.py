from __future__ import annotations

from dataclasses import dataclass

import polars as pl

from factor_engine.ast_nodes import (
    BinaryOpNode,
    BooleanNode,
    CallNode,
    Expr,
    ListNode,
    NumberNode,
    UnaryOpNode,
    VariableNode,
)
from factor_engine.errors import ExecutionError
from factor_engine.fourier import fourier_transform_frame
from factor_engine.registry import get_function_spec
from factor_engine.validator import ExecutionProfile, ValidationResult


SegmentSpecKey = tuple[str, int | tuple[int, ...]]


def _rolling_recent_arg_extreme(window: pl.Series, *, mode: str) -> int | None:
    values = window.to_list()
    target_index: int | None = None
    target_value: float | int | None = None

    for index, value in enumerate(values):
        if value is None:
            continue

        if target_index is None:
            target_index = index
            target_value = value
            continue

        if mode == "max":
            is_better = value > target_value or (value == target_value and index > target_index)
        else:
            is_better = value < target_value or (value == target_value and index > target_index)

        if is_better:
            target_index = index
            target_value = value

    if target_index is None:
        return None

    return len(values) - 1 - target_index


@dataclass
class PreparedFrame:
    # PreparedFrame is an internal optimization helper for ordered time-series work.
    original_df: pl.DataFrame
    sorted_df: pl.DataFrame
    row_index_name: str
    segmented_views: dict[SegmentSpecKey, pl.DataFrame]

    def restore_output_columns(self, output_names: list[str]) -> pl.DataFrame:
        return (
            self.sorted_df.select([self.row_index_name, *output_names])
            .sort(self.row_index_name)
            .drop(self.row_index_name)
        )


class Executor:
    def __init__(
        self,
        df: pl.DataFrame,
        time_col: str = "time",
        code_col: str = "code",
    ):
        self.df = df
        self.time_col = time_col
        self.code_col = code_col
        self._prepared_frame: PreparedFrame | None = None
        self._segment_id_name = self._temporary_helper_name("__segment_id")
        self._code_pos_name = self._temporary_helper_name(
            "__code_pos",
            reserved={self._segment_id_name},
        )
        self._code_len_name = self._temporary_helper_name(
            "__code_len",
            reserved={self._segment_id_name, self._code_pos_name},
        )

    def _temporary_helper_name(
        self,
        base_name: str,
        *,
        reserved: set[str] | None = None,
    ) -> str:
        used_names = set(self.df.columns)
        if reserved is not None:
            used_names.update(reserved)

        candidate = base_name
        while candidate in used_names:
            candidate = f"_{candidate}"
        return candidate

    def compile(self, expr: Expr) -> pl.Expr:
        return self._compile_expr(expr)

    def evaluate(
        self,
        expr: Expr,
        output_name: str = "result",
        validation: ValidationResult | None = None,
    ) -> pl.DataFrame:
        # Column expressions keep the original row shape; table expressions do not.
        if validation is not None and validation.result_kind == "table":
            return self._evaluate_table(expr, validation)

        profile = (
            validation.profile if validation is not None else self._infer_execution_profile(expr)
        )
        return self._evaluate_column(expr, output_name=output_name, profile=profile)

    def evaluate_compiled(
        self,
        compiled: pl.Expr,
        *,
        output_name: str = "result",
        validation: ValidationResult,
    ) -> pl.DataFrame:
        if validation.result_kind != "column":
            raise ExecutionError("evaluate_compiled() only supports column expressions")

        return self._evaluate_compiled_column(
            compiled,
            output_name=output_name,
            profile=validation.profile,
        )

    def evaluate_many(
        self,
        items: list[tuple[str, Expr, ValidationResult]],
    ) -> pl.DataFrame:
        compiled_items: list[tuple[str, ValidationResult, pl.Expr]] = []
        deferred_items: list[tuple[str, Expr, ValidationResult]] = []

        for output_name, expr, validation in items:
            if self._expr_uses_segmented_window(expr):
                deferred_items.append((output_name, expr, validation))
            else:
                compiled_items.append((output_name, validation, self.compile(expr)))

        result_df = self.df
        if compiled_items:
            result_df = Executor(
                result_df,
                time_col=self.time_col,
                code_col=self.code_col,
            ).evaluate_many_compiled(compiled_items)

        if deferred_items:
            result_df = Executor(
                result_df,
                time_col=self.time_col,
                code_col=self.code_col,
            )._evaluate_many_segmented_columns(deferred_items)

        original_columns = list(self.df.columns)
        appended_columns = [output_name for output_name, _, _ in items if output_name not in original_columns]
        return result_df.select([*original_columns, *appended_columns])

    def evaluate_many_compiled(
        self,
        items: list[tuple[str, ValidationResult, pl.Expr]],
    ) -> pl.DataFrame:
        if not items:
            return self.df

        no_time_order_items: list[tuple[str, pl.Expr]] = []
        time_ordered_items: list[tuple[str, pl.Expr]] = []

        for output_name, validation, compiled in items:
            if validation.result_kind != "column":
                raise ExecutionError("evaluate_many_compiled() only supports column expressions")

            if validation.profile.needs_time_order:
                time_ordered_items.append((output_name, compiled))
            else:
                no_time_order_items.append((output_name, compiled))

        result_df = self.df

        if no_time_order_items:
            result_df = self._evaluate_many_row_aligned_no_time_order(
                result_df,
                no_time_order_items,
            )

        if time_ordered_items:
            ordered_columns = self._evaluate_many_row_aligned_time_ordered(time_ordered_items)
            result_df = result_df.with_columns(
                [ordered_columns.get_column(output_name) for output_name, _ in time_ordered_items]
            )

        original_columns = list(self.df.columns)
        appended_columns = [output_name for output_name, _, _ in items if output_name not in original_columns]
        return result_df.select([*original_columns, *appended_columns])

    def _evaluate_column(
        self,
        expr: Expr,
        *,
        output_name: str,
        profile: ExecutionProfile,
    ) -> pl.DataFrame:
        if self._expr_uses_segmented_window(expr):
            return self._evaluate_segmented_column(expr, output_name=output_name)

        compiled = self.compile(expr)
        return self._evaluate_compiled_column(
            compiled,
            output_name=output_name,
            profile=profile,
        )

    def _evaluate_compiled_column(
        self,
        compiled: pl.Expr,
        *,
        output_name: str,
        profile: ExecutionProfile,
    ) -> pl.DataFrame:
        if profile.needs_time_order:
            return self._evaluate_row_aligned_time_ordered(compiled, output_name=output_name)

        return self._evaluate_row_aligned_no_time_order(compiled, output_name=output_name)

    def _evaluate_row_aligned_no_time_order(
        self,
        compiled: pl.Expr,
        *,
        output_name: str,
    ) -> pl.DataFrame:
        # Pointwise and cross-sectional expressions can stay on the original row order.
        return self.df.with_columns(compiled.alias(output_name))

    def _evaluate_row_aligned_time_ordered(
        self,
        compiled: pl.Expr,
        *,
        output_name: str,
    ) -> pl.DataFrame:
        prepared = self._get_prepared_frame()
        sorted_df = prepared.sorted_df.with_columns(compiled.alias(output_name))
        return (
            sorted_df.sort(prepared.row_index_name)
            .drop(prepared.row_index_name)
        )

    def _evaluate_many_row_aligned_no_time_order(
        self,
        base_df: pl.DataFrame,
        items: list[tuple[str, pl.Expr]],
    ) -> pl.DataFrame:
        compiled = [expr.alias(output_name) for output_name, expr in items]
        return base_df.with_columns(compiled)

    def _evaluate_many_row_aligned_time_ordered(
        self,
        items: list[tuple[str, pl.Expr]],
    ) -> pl.DataFrame:
        prepared = self._get_prepared_frame()
        compiled = [expr.alias(output_name) for output_name, expr in items]

        prepared.sorted_df = prepared.sorted_df.with_columns(compiled)
        return prepared.restore_output_columns([output_name for output_name, _ in items])

    def _evaluate_segmented_column(
        self,
        expr: Expr,
        *,
        output_name: str,
    ) -> pl.DataFrame:
        prepared = self._get_prepared_frame()
        segment_spec_key = self._get_segment_spec_key(expr)
        segmented_df = self._get_segmented_view(segment_spec_key)
        compiled = self._compile_expr(expr)
        result_df = segmented_df.with_columns(compiled.alias(output_name))

        return (
            result_df.select([prepared.row_index_name, *self.df.columns, output_name])
            .sort(prepared.row_index_name)
            .drop(prepared.row_index_name)
        )

    def _evaluate_many_segmented_columns(
        self,
        items: list[tuple[str, Expr, ValidationResult]],
    ) -> pl.DataFrame:
        if not items:
            return self.df

        prepared = self._get_prepared_frame()
        outputs_by_name: dict[str, pl.Series] = {}
        items_by_segment_spec: dict[SegmentSpecKey, list[tuple[str, Expr]]] = {}

        for output_name, expr, _validation in items:
            segment_spec_key = self._get_segment_spec_key(expr)
            items_by_segment_spec.setdefault(segment_spec_key, []).append((output_name, expr))

        for segment_spec_key, grouped_items in items_by_segment_spec.items():
            segmented_df = self._get_segmented_view(segment_spec_key)
            compiled = [
                self._compile_expr(expr).alias(output_name)
                for output_name, expr in grouped_items
            ]
            grouped_result = (
                segmented_df.select([prepared.row_index_name, *compiled])
                .sort(prepared.row_index_name)
                .drop(prepared.row_index_name)
            )
            for output_name, _expr in grouped_items:
                outputs_by_name[output_name] = grouped_result.get_column(output_name)

        return self.df.with_columns([outputs_by_name[output_name] for output_name, _expr, _validation in items])

    def _get_prepared_frame(self) -> PreparedFrame:
        if self.time_col not in self.df.columns or self.code_col not in self.df.columns:
            raise ExecutionError(
                f"Ordered time-series execution requires columns: {self.code_col}, {self.time_col}"
            )

        if self._prepared_frame is None:
            row_index_name = "__row_idx"
            while row_index_name in self.df.columns:
                row_index_name = f"_{row_index_name}"

            sorted_df = (
                self.df.with_row_index(row_index_name)
                .sort([self.code_col, self.time_col])
            )
            self._prepared_frame = PreparedFrame(
                original_df=self.df,
                sorted_df=sorted_df,
                row_index_name=row_index_name,
                segmented_views={},
            )

        return self._prepared_frame

    def _get_segmented_view(self, segment_spec_key: SegmentSpecKey) -> pl.DataFrame:
        prepared = self._get_prepared_frame()
        segmented_view = prepared.segmented_views.get(segment_spec_key)
        if segmented_view is not None:
            return segmented_view

        # Segment views are cached per immutable spec key so evaluate_many() can
        # reuse the same ordered split across multiple segmented expressions.
        segmented_view = self._prepare_segmented_sorted_df(
            prepared.sorted_df,
            segment_spec_key=segment_spec_key,
        )
        prepared.segmented_views[segment_spec_key] = segmented_view
        return segmented_view

    def _evaluate_table(self, expr: Expr, validation: ValidationResult) -> pl.DataFrame:
        if validation.backend == "fft":
            return self._evaluate_fft(expr)

        raise ExecutionError(f"Unsupported table backend: {validation.backend}")

    def _infer_execution_profile(self, expr: Expr) -> ExecutionProfile:
        # Executor keeps a lightweight fallback so direct Executor.evaluate(...) calls
        # still choose the right execution path when no ValidationResult is provided.
        if isinstance(expr, (NumberNode, BooleanNode, VariableNode)):
            return ExecutionProfile.column()

        if isinstance(expr, ListNode):
            raise ExecutionError("List literals cannot be evaluated as standalone expressions")

        if isinstance(expr, UnaryOpNode):
            return self._infer_execution_profile(expr.operand)

        if isinstance(expr, BinaryOpNode):
            return ExecutionProfile.merge(
                self._infer_execution_profile(expr.left),
                self._infer_execution_profile(expr.right),
            )

        if isinstance(expr, CallNode):
            spec = get_function_spec(expr.name)
            child_profiles = [
                self._infer_execution_profile(arg)
                for index, arg in enumerate(expr.args)
                if not (spec is not None and spec.window_kind == "segmented" and index == 1)
            ]
            child_profiles.extend(self._infer_execution_profile(value) for value in expr.kwargs.values())
            if spec is None:
                return ExecutionProfile.merge(*child_profiles)
            return ExecutionProfile.merge(
                *child_profiles,
                result_kind=spec.result_kind,
                self_needs_code_group=spec.needs_code_group,
                self_needs_time_group=spec.needs_time_group,
                self_needs_time_order=spec.needs_time_order,
            )

        raise ExecutionError(f"Unsupported AST node for execution profiling: {type(expr).__name__}")

    def _evaluate_fft(self, expr: Expr) -> pl.DataFrame:
        # Validation guarantees the root shape, so execution can dispatch to the backend directly.
        if not isinstance(expr, CallNode) or len(expr.args) != 1:
            raise ExecutionError("Internal error: fft evaluation expects fft(column)")

        argument = expr.args[0]
        if not isinstance(argument, VariableNode):
            raise ExecutionError("Internal error: fft evaluation expects a direct column reference")

        try:
            return fourier_transform_frame(
                self.df,
                value_col=argument.name,
                time_col=self.time_col,
                code_col=self.code_col,
            )
        except ValueError as exc:
            raise ExecutionError(str(exc)) from exc

    def _compile_expr(self, expr: Expr) -> pl.Expr:
        if isinstance(expr, NumberNode):
            return pl.lit(expr.value)

        if isinstance(expr, BooleanNode):
            return pl.lit(expr.value)

        if isinstance(expr, ListNode):
            raise ExecutionError("List literals cannot be compiled as column expressions")

        if isinstance(expr, VariableNode):
            return pl.col(expr.name)

        if isinstance(expr, UnaryOpNode):
            operand = self._compile_expr(expr.operand)
            if expr.operator == "+":
                return operand
            if expr.operator == "-":
                return -operand
            if expr.operator == "not":
                return ~operand
            raise ExecutionError(f"Unsupported unary operator: {expr.operator}")

        if isinstance(expr, BinaryOpNode):
            return self._compile_binary(expr)

        if isinstance(expr, CallNode):
            return self._compile_call(expr)

        raise ExecutionError(f"Unsupported AST node: {type(expr).__name__}")

    def _compile_binary(self, expr: BinaryOpNode) -> pl.Expr:
        left = self._compile_expr(expr.left)
        right = self._compile_expr(expr.right)

        if expr.operator == "+":
            return left + right
        if expr.operator == "-":
            return left - right
        if expr.operator == "*":
            return left * right
        if expr.operator == "/":
            return left / right

        if expr.operator == ">":
            return left > right
        if expr.operator == "<":
            return left < right
        if expr.operator == ">=":
            return left >= right
        if expr.operator == "<=":
            return left <= right
        if expr.operator == "==":
            return left == right
        if expr.operator == "and":
            return left & right
        if expr.operator == "or":
            return left | right

        raise ExecutionError(f"Unsupported binary operator: {expr.operator}")

    def _compile_call(self, expr: CallNode) -> pl.Expr:
        if expr.name == "abs":
            return self._compile_abs(expr)
        if expr.name == "argmax":
            return self._compile_argmax(expr)
        if expr.name == "argmin":
            return self._compile_argmin(expr)
        if expr.name == "clip":
            return self._compile_clip(expr)
        if expr.name == "corr":
            return self._compile_corr(expr)
        if expr.name == "cov":
            return self._compile_cov(expr)
        if expr.name == "delta":
            return self._compile_delta(expr)
        if expr.name == "where":
            return self._compile_where(expr)
        if expr.name == "delay":
            return self._compile_delay(expr)
        if expr.name == "skew":
            return self._compile_skew(expr)
        if expr.name == "kurt":
            return self._compile_kurt(expr)
        if expr.name == "pct_change":
            return self._compile_pct_change(expr)
        if expr.name == "ts_max":
            return self._compile_ts_max(expr)
        if expr.name == "ts_median":
            return self._compile_ts_median(expr)
        if expr.name == "ts_mean":
            return self._compile_ts_mean(expr)
        if expr.name == "ts_min":
            return self._compile_ts_min(expr)
        if expr.name == "ts_sum":
            return self._compile_ts_sum(expr)
        if expr.name == "ts_std":
            return self._compile_ts_std(expr)
        if expr.name == "demean":
            return self._compile_demean(expr)
        if expr.name == "fill_null":
            return self._compile_fill_null(expr)
        if expr.name == "group_demean":
            return self._compile_group_demean(expr)
        if expr.name == "group_rank":
            return self._compile_group_rank(expr)
        if expr.name == "group_zscore":
            return self._compile_group_zscore(expr)
        if expr.name == "is_null":
            return self._compile_is_null(expr)
        if expr.name == "zscore":
            return self._compile_zscore(expr)
        if expr.name == "rank":
            return self._compile_rank(expr)
        if expr.name == "seg_all":
            return self._compile_seg_all(expr)
        if expr.name == "seg_any":
            return self._compile_seg_any(expr)
        if expr.name == "seg_count":
            return self._compile_seg_count(expr)
        if expr.name == "seglen_all":
            return self._compile_seglen_all(expr)
        if expr.name == "seglen_any":
            return self._compile_seglen_any(expr)
        if expr.name == "seglen_count":
            return self._compile_seglen_count(expr)
        if expr.name == "seglen_mean":
            return self._compile_seglen_mean(expr)
        if expr.name == "seglen_sum":
            return self._compile_seglen_sum(expr)
        if expr.name == "seg_mean":
            return self._compile_seg_mean(expr)
        if expr.name == "seg_sum":
            return self._compile_seg_sum(expr)
        if expr.name == "sign":
            return self._compile_sign(expr)
        if expr.name == "ts_all":
            return self._compile_ts_all(expr)
        if expr.name == "ts_any":
            return self._compile_ts_any(expr)
        if expr.name == "ts_count":
            return self._compile_ts_count(expr)
        if expr.name == "ts_rank":
            return self._compile_ts_rank(expr)

        raise ExecutionError(f"Unsupported function in executor: {expr.name}")

    def _compile_abs(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 1 or expr.kwargs:
            raise ExecutionError("abs(x) expects exactly 1 positional argument")

        return self._compile_expr(expr.args[0]).abs()

    def _compile_argmax(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("argmax(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "argmax")

        if window == 0:
            raise ExecutionError("Function 'argmax' requires window > 0")

        return (
            value_expr.rolling_map(
                lambda window_values: _rolling_recent_arg_extreme(window_values, mode="max"),
                window_size=window,
                min_samples=1,
            )
            .over(self.code_col)
            .cast(pl.Int64)
        )

    def _compile_argmin(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("argmin(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "argmin")

        if window == 0:
            raise ExecutionError("Function 'argmin' requires window > 0")

        return (
            value_expr.rolling_map(
                lambda window_values: _rolling_recent_arg_extreme(window_values, mode="min"),
                window_size=window,
                min_samples=1,
            )
            .over(self.code_col)
            .cast(pl.Int64)
        )

    def _compile_fill_null(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("fill_null(x, v) expects exactly 2 positional arguments")

        value_expr = self._compile_expr(expr.args[0])
        fill_expr = self._compile_expr(expr.args[1])
        return value_expr.fill_null(fill_expr)

    def _compile_is_null(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 1 or expr.kwargs:
            raise ExecutionError("is_null(x) expects exactly 1 positional argument")

        return self._compile_expr(expr.args[0]).is_null()

    def _compile_clip(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 3 or expr.kwargs:
            raise ExecutionError("clip(x, lower, upper) expects exactly 3 positional arguments")

        value_expr = self._compile_expr(expr.args[0])
        lower_expr = self._compile_expr(expr.args[1])
        upper_expr = self._compile_expr(expr.args[2])

        return (
            pl.when(value_expr < lower_expr)
            .then(lower_expr)
            .when(value_expr > upper_expr)
            .then(upper_expr)
            .otherwise(value_expr)
        )

    def _compile_where(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 3 or expr.kwargs:
            raise ExecutionError("where(cond, a, b) expects exactly 3 positional arguments")

        condition = self._compile_expr(expr.args[0])
        true_value = self._compile_expr(expr.args[1])
        false_value = self._compile_expr(expr.args[2])

        return pl.when(condition).then(true_value).otherwise(false_value)

    def _expect_numeric_literal(self, expr: Expr, func_name: str) -> int:
        if not isinstance(expr, NumberNode):
            raise ExecutionError(
                f"Function '{func_name}' requires an integer literal window argument"
            )

        value = expr.value
        if int(value) != value or value < 0:
            raise ExecutionError(
                f"Function '{func_name}' requires a non-negative integer argument"
            )

        return int(value)

    def _expect_positive_numeric_literal(self, expr: Expr, func_name: str) -> int:
        value = self._expect_numeric_literal(expr, func_name)
        if value <= 0:
            raise ExecutionError(
                f"Function '{func_name}' requires a positive integer argument"
            )
        return value

    def _expect_positive_integer_list_literal(
        self,
        expr: Expr,
        func_name: str,
    ) -> tuple[int, ...]:
        if not isinstance(expr, ListNode) or not expr.items:
            raise ExecutionError(
                f"Function '{func_name}' requires a positive integer literal length list"
            )

        values: list[int] = []
        for item in expr.items:
            if not isinstance(item, NumberNode):
                raise ExecutionError(
                    f"Function '{func_name}' requires a positive integer literal length list"
                )

            value = item.value
            if int(value) != value or value <= 0:
                raise ExecutionError(
                    f"Function '{func_name}' requires a positive integer literal length list"
                )
            values.append(int(value))

        return tuple(values)

    def _expect_window_at_least(self, expr: Expr, func_name: str, minimum: int) -> int:
        window = self._expect_numeric_literal(expr, func_name)
        if window < minimum:
            raise ExecutionError(f"Function '{func_name}' requires window >= {minimum}")
        return window

    def _compile_time_series_input(self, expr: Expr) -> pl.Expr:
        return self._compile_expr(expr)

    def _compile_boolean_time_series_input(self, expr: Expr) -> pl.Expr:
        return self._compile_expr(expr)

    def _compile_boolean_window_as_int(self, expr: Expr) -> pl.Expr:
        # Boolean windows use fill_null(false) so ts_count/ts_any/ts_all share
        # one explicit and conservative null contract across the engine.
        condition_expr = self._compile_boolean_time_series_input(expr)
        return pl.when(condition_expr.fill_null(False)).then(1).otherwise(0)

    def _compile_boolean_segmented_as_int(self, expr: Expr) -> pl.Expr:
        # Segmented boolean reducers intentionally share the same null contract as
        # rolling boolean reducers so users do not have to remember two rule sets.
        return self._compile_boolean_window_as_int(expr)

    def _compile_corr(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 3 or expr.kwargs:
            raise ExecutionError("corr(x, y, n) expects exactly 3 positional arguments")

        left_expr = self._compile_time_series_input(expr.args[0])
        right_expr = self._compile_time_series_input(expr.args[1])
        window = self._expect_window_at_least(expr.args[2], "corr", 2)

        return pl.rolling_corr(
            left_expr,
            right_expr,
            window_size=window,
            min_samples=2,
        ).over(self.code_col)

    def _compile_cov(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 3 or expr.kwargs:
            raise ExecutionError("cov(x, y, n) expects exactly 3 positional arguments")

        left_expr = self._compile_time_series_input(expr.args[0])
        right_expr = self._compile_time_series_input(expr.args[1])
        window = self._expect_window_at_least(expr.args[2], "cov", 2)

        return pl.rolling_cov(
            left_expr,
            right_expr,
            window_size=window,
            min_samples=2,
        ).over(self.code_col)

    def _compile_seg_mean(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("seg_mean(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        self._expect_positive_numeric_literal(expr.args[1], "seg_mean")
        return value_expr.mean().over([self.code_col, self._segment_id_name])

    def _compile_seglen_mean(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError(
                "seglen_mean(x, [l1, l2, ...]) expects exactly 2 positional arguments"
            )

        value_expr = self._compile_time_series_input(expr.args[0])
        self._expect_positive_integer_list_literal(expr.args[1], "seglen_mean")
        return value_expr.mean().over([self.code_col, self._segment_id_name])

    def _compile_seglen_sum(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError(
                "seglen_sum(x, [l1, l2, ...]) expects exactly 2 positional arguments"
            )

        value_expr = self._compile_time_series_input(expr.args[0])
        self._expect_positive_integer_list_literal(expr.args[1], "seglen_sum")
        return value_expr.sum().over([self.code_col, self._segment_id_name])

    def _compile_seglen_count(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError(
                "seglen_count(cond, [l1, l2, ...]) expects exactly 2 positional arguments"
            )

        condition_expr = self._compile_boolean_segmented_as_int(expr.args[0])
        self._expect_positive_integer_list_literal(expr.args[1], "seglen_count")
        return condition_expr.sum().over([self.code_col, self._segment_id_name])

    def _compile_seglen_any(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError(
                "seglen_any(cond, [l1, l2, ...]) expects exactly 2 positional arguments"
            )

        condition_expr = self._compile_boolean_segmented_as_int(expr.args[0])
        self._expect_positive_integer_list_literal(expr.args[1], "seglen_any")
        return condition_expr.max().over([self.code_col, self._segment_id_name]) > 0

    def _compile_seglen_all(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError(
                "seglen_all(cond, [l1, l2, ...]) expects exactly 2 positional arguments"
            )

        condition_expr = self._compile_boolean_segmented_as_int(expr.args[0])
        self._expect_positive_integer_list_literal(expr.args[1], "seglen_all")
        return condition_expr.min().over([self.code_col, self._segment_id_name]) == 1

    def _compile_seg_sum(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("seg_sum(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        self._expect_positive_numeric_literal(expr.args[1], "seg_sum")
        return value_expr.sum().over([self.code_col, self._segment_id_name])

    def _compile_seg_count(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("seg_count(cond, n) expects exactly 2 positional arguments")

        condition_expr = self._compile_boolean_segmented_as_int(expr.args[0])
        self._expect_positive_numeric_literal(expr.args[1], "seg_count")
        return condition_expr.sum().over([self.code_col, self._segment_id_name])

    def _compile_seg_any(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("seg_any(cond, n) expects exactly 2 positional arguments")

        condition_expr = self._compile_boolean_segmented_as_int(expr.args[0])
        self._expect_positive_numeric_literal(expr.args[1], "seg_any")
        return condition_expr.max().over([self.code_col, self._segment_id_name]) > 0

    def _compile_seg_all(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("seg_all(cond, n) expects exactly 2 positional arguments")

        condition_expr = self._compile_boolean_segmented_as_int(expr.args[0])
        self._expect_positive_numeric_literal(expr.args[1], "seg_all")
        return condition_expr.min().over([self.code_col, self._segment_id_name]) == 1

    def _compile_delay(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("delay(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        periods = self._expect_numeric_literal(expr.args[1], "delay")

        return self._compile_shifted_time_series(value_expr, periods)

    def _compile_delta(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("delta(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        periods = self._expect_numeric_literal(expr.args[1], "delta")

        # Keep delta aligned with the documented engine semantics: x - delay(x, n).
        return value_expr - self._compile_shifted_time_series(value_expr, periods)

    def _compile_ts_mean(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("ts_mean(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "ts_mean")

        if window == 0:
            raise ExecutionError("Function 'ts_mean' requires window > 0")

        return value_expr.rolling_mean(
            window_size=window,
            min_samples=1,
        ).over(self.code_col)

    def _compile_ts_min(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("ts_min(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "ts_min")

        if window == 0:
            raise ExecutionError("Function 'ts_min' requires window > 0")

        return value_expr.rolling_min(
            window_size=window,
            min_samples=1,
        ).over(self.code_col)

    def _compile_ts_max(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("ts_max(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "ts_max")

        if window == 0:
            raise ExecutionError("Function 'ts_max' requires window > 0")

        return value_expr.rolling_max(
            window_size=window,
            min_samples=1,
        ).over(self.code_col)

    def _compile_ts_median(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("ts_median(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "ts_median")

        if window == 0:
            raise ExecutionError("Function 'ts_median' requires window > 0")

        return value_expr.rolling_median(
            window_size=window,
            min_samples=1,
        ).over(self.code_col)

    def _compile_ts_sum(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("ts_sum(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "ts_sum")

        if window == 0:
            raise ExecutionError("Function 'ts_sum' requires window > 0")

        return value_expr.rolling_sum(
            window_size=window,
            min_samples=1,
        ).over(self.code_col)

    def _compile_ts_std(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("ts_std(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "ts_std")

        if window == 0:
            raise ExecutionError("Function 'ts_std' requires window > 0")

        return value_expr.rolling_std(
            window_size=window,
            min_samples=2,
        ).over(self.code_col)

    def _compile_ts_count(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("ts_count(cond, n) expects exactly 2 positional arguments")

        condition_expr = self._compile_boolean_window_as_int(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "ts_count")
        if window == 0:
            raise ExecutionError("Function 'ts_count' requires window > 0")

        return condition_expr.rolling_sum(
            window_size=window,
            min_samples=1,
        ).over(self.code_col)

    def _compile_ts_any(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("ts_any(cond, n) expects exactly 2 positional arguments")

        condition_expr = self._compile_boolean_window_as_int(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "ts_any")
        if window == 0:
            raise ExecutionError("Function 'ts_any' requires window > 0")

        return condition_expr.rolling_max(
            window_size=window,
            min_samples=1,
        ).over(self.code_col) > 0

    def _compile_ts_all(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("ts_all(cond, n) expects exactly 2 positional arguments")

        condition_expr = self._compile_boolean_window_as_int(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "ts_all")
        if window == 0:
            raise ExecutionError("Function 'ts_all' requires window > 0")

        return condition_expr.rolling_min(
            window_size=window,
            min_samples=1,
        ).over(self.code_col) == 1

    def _compile_ts_rank(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2:
            raise ExecutionError("ts_rank(x, n, ...) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_numeric_literal(expr.args[1], "ts_rank")
        if window == 0:
            raise ExecutionError("Function 'ts_rank' requires window > 0")

        ascending = False
        pct = False

        if "ascending" in expr.kwargs:
            ascending = self._expect_boolean_literal(expr.kwargs["ascending"], "ts_rank")

        if "pct" in expr.kwargs:
            pct = self._expect_boolean_literal(expr.kwargs["pct"], "ts_rank")

        ranked_input = value_expr if ascending else -value_expr
        rank_expr = ranked_input.rolling_rank(
            window_size=window,
            method="average",
            min_samples=1,
        ).over(self.code_col)

        if pct:
            sample_count_expr = value_expr.is_not_null().cast(pl.Int64).rolling_sum(
                window_size=window,
                min_samples=1,
            ).over(self.code_col)
            return rank_expr / sample_count_expr

        return rank_expr

    def _compile_skew(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("skew(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_window_at_least(expr.args[1], "skew", 3)

        return value_expr.rolling_skew(
            window_size=window,
            min_samples=3,
        ).over(self.code_col)

    def _compile_kurt(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("kurt(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        window = self._expect_window_at_least(expr.args[1], "kurt", 4)

        return value_expr.rolling_kurtosis(
            window_size=window,
            fisher=True,
            bias=True,
            min_samples=4,
        ).over(self.code_col)

    def _compile_pct_change(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("pct_change(x, n) expects exactly 2 positional arguments")

        value_expr = self._compile_time_series_input(expr.args[0])
        periods = self._expect_numeric_literal(expr.args[1], "pct_change")

        # pct_change intentionally follows the engine-level arithmetic definition.
        delayed_expr = self._compile_shifted_time_series(value_expr, periods)
        return value_expr / delayed_expr - 1

    def _compile_demean(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 1 or expr.kwargs:
            raise ExecutionError("demean(x) expects exactly 1 positional argument")

        value_expr = self._compile_expr(expr.args[0])
        mean_expr = value_expr.mean().over(self.time_col)
        return value_expr - mean_expr

    def _compile_group_demean(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("group_demean(x, group) expects exactly 2 positional arguments")

        value_expr = self._compile_expr(expr.args[0])
        group_col = self._expect_group_column(expr, func_name="group_demean")
        mean_expr = value_expr.mean().over([self.time_col, group_col])
        return value_expr - mean_expr

    def _compile_zscore(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 1 or expr.kwargs:
            raise ExecutionError("zscore(x) expects exactly 1 positional argument")

        value_expr = self._compile_expr(expr.args[0])
        mean_expr = value_expr.mean().over(self.time_col)
        std_expr = value_expr.std().over(self.time_col)

        return (value_expr - mean_expr) / std_expr

    def _compile_group_zscore(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2 or expr.kwargs:
            raise ExecutionError("group_zscore(x, group) expects exactly 2 positional arguments")

        value_expr = self._compile_expr(expr.args[0])
        group_col = self._expect_group_column(expr, func_name="group_zscore")
        mean_expr = value_expr.mean().over([self.time_col, group_col])
        std_expr = value_expr.std().over([self.time_col, group_col])

        return (value_expr - mean_expr) / std_expr

    def _compile_rank(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 1:
            raise ExecutionError("rank(x, ...) expects exactly 1 positional argument")

        value_expr = self._compile_expr(expr.args[0])

        ascending = False
        pct = False

        if "ascending" in expr.kwargs:
            ascending = self._expect_boolean_literal(expr.kwargs["ascending"], "rank")

        if "pct" in expr.kwargs:
            pct = self._expect_boolean_literal(expr.kwargs["pct"], "rank")

        rank_expr = value_expr.rank(descending=not ascending).over(self.time_col)

        if pct:
            count_expr = pl.len().over(self.time_col)
            return rank_expr / count_expr

        return rank_expr

    def _compile_group_rank(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 2:
            raise ExecutionError("group_rank(x, group, ...) expects exactly 2 positional arguments")

        value_expr = self._compile_expr(expr.args[0])
        group_col = self._expect_group_column(expr, func_name="group_rank")

        ascending = False
        pct = False

        if "ascending" in expr.kwargs:
            ascending = self._expect_boolean_literal(expr.kwargs["ascending"], "group_rank")

        if "pct" in expr.kwargs:
            pct = self._expect_boolean_literal(expr.kwargs["pct"], "group_rank")

        partition = [self.time_col, group_col]
        rank_expr = value_expr.rank(descending=not ascending).over(partition)

        if pct:
            count_expr = pl.len().over(partition)
            return rank_expr / count_expr

        return rank_expr

    def _compile_sign(self, expr: CallNode) -> pl.Expr:
        if len(expr.args) != 1 or expr.kwargs:
            raise ExecutionError("sign(x) expects exactly 1 positional argument")

        value_expr = self._compile_expr(expr.args[0])
        return (
            pl.when(value_expr.is_null())
            .then(None)
            .when(value_expr < 0)
            .then(-1.0)
            .when(value_expr > 0)
            .then(1.0)
            .otherwise(0.0)
        )

    def _expect_group_column(self, expr: CallNode, *, func_name: str) -> str:
        if len(expr.args) < 2 or not isinstance(expr.args[1], VariableNode):
            raise ExecutionError(
                f"Function '{func_name}' requires a direct group column reference as the second argument"
            )
        return expr.args[1].name

    def _expect_boolean_literal(self, expr: Expr, func_name: str) -> bool:
        if not isinstance(expr, BooleanNode):
            raise ExecutionError(
                f"Function '{func_name}' requires boolean literal keyword arguments"
            )
        return expr.value

    def _compile_shifted_time_series(self, value_expr: pl.Expr, periods: int) -> pl.Expr:
        return value_expr.shift(periods).over(self.code_col)

    def _expr_uses_segmented_window(self, expr: Expr) -> bool:
        if isinstance(expr, CallNode):
            spec = get_function_spec(expr.name)
            if spec is not None and spec.window_kind == "segmented":
                return True
            return any(self._expr_uses_segmented_window(arg) for arg in expr.args) or any(
                self._expr_uses_segmented_window(value) for value in expr.kwargs.values()
            )

        if isinstance(expr, UnaryOpNode):
            return self._expr_uses_segmented_window(expr.operand)

        if isinstance(expr, BinaryOpNode):
            return self._expr_uses_segmented_window(expr.left) or self._expr_uses_segmented_window(
                expr.right
            )

        return False

    def _get_segment_spec_key(self, expr: Expr) -> SegmentSpecKey:
        segment_specs: set[SegmentSpecKey] = set()
        self._collect_segment_spec_keys(expr, specs=segment_specs)

        if not segment_specs:
            raise ExecutionError("Internal error: segmented execution requested without segmented calls")

        if len(segment_specs) != 1:
            raise ExecutionError(
                "Current segmented execution supports one segment spec per expression"
            )

        return next(iter(segment_specs))

    def _collect_segment_spec_keys(
        self,
        expr: Expr,
        *,
        specs: set[SegmentSpecKey],
    ) -> None:
        if isinstance(expr, CallNode):
            spec = get_function_spec(expr.name)
            if spec is not None and spec.window_kind == "segmented":
                if len(expr.args) < 2:
                    raise ExecutionError(f"Function '{expr.name}' requires a segment specification")
                specs.add(self._get_segment_spec_key_from_call(expr))

            for arg in expr.args:
                self._collect_segment_spec_keys(arg, specs=specs)
            for value in expr.kwargs.values():
                self._collect_segment_spec_keys(value, specs=specs)
            return

        if isinstance(expr, UnaryOpNode):
            self._collect_segment_spec_keys(expr.operand, specs=specs)
            return

        if isinstance(expr, BinaryOpNode):
            self._collect_segment_spec_keys(expr.left, specs=specs)
            self._collect_segment_spec_keys(expr.right, specs=specs)

    def _get_segment_spec_key_from_call(self, expr: CallNode) -> SegmentSpecKey:
        if len(expr.args) < 2:
            raise ExecutionError(f"Function '{expr.name}' requires a segment specification")

        if expr.name.startswith("seglen_"):
            return ("length", self._expect_positive_integer_list_literal(expr.args[1], expr.name))

        return ("equal", self._expect_positive_numeric_literal(expr.args[1], expr.name))

    def _prepare_segmented_sorted_df(
        self,
        sorted_df: pl.DataFrame,
        *,
        segment_spec_key: SegmentSpecKey,
    ) -> pl.DataFrame:
        with_group_position = sorted_df.with_columns(
            [
                (pl.col(self.code_col).cum_count().over(self.code_col) - 1).alias(
                    self._code_pos_name
                ),
                pl.len().over(self.code_col).alias(self._code_len_name),
            ]
        )

        kind, spec_value = segment_spec_key
        if kind == "equal":
            if not isinstance(spec_value, int):
                raise ExecutionError("Internal error: invalid equal segment specification")
            segment_id_expr = self._build_equal_segment_id_expr(spec_value)
        elif kind == "length":
            if not isinstance(spec_value, tuple):
                raise ExecutionError("Internal error: invalid length segment specification")
            self._ensure_segment_lengths_cover_groups(with_group_position, spec_value)
            segment_id_expr = self._build_length_segment_id_expr(spec_value)
        else:
            raise ExecutionError(f"Internal error: unsupported segment specification kind '{kind}'")

        return with_group_position.with_columns(segment_id_expr.alias(self._segment_id_name))

    def _build_equal_segment_id_expr(self, segment_count: int) -> pl.Expr:
        code_pos = pl.col(self._code_pos_name)
        code_len = pl.col(self._code_len_name)
        segment_count_lit = pl.lit(segment_count)
        base_size = code_len // segment_count_lit
        larger_segment_count = code_len % segment_count_lit
        larger_segment_rows = (base_size + 1) * larger_segment_count

        # Segment remainders are assigned to the earliest buckets so the split
        # stays deterministic and the n > m case naturally collapses to 1-row segments.
        segment_id_expr = (
            pl.when(code_pos < larger_segment_rows)
            .then(code_pos // (base_size + 1))
            .otherwise(
                pl.when(base_size > 0)
                .then(
                    larger_segment_count
                    + ((code_pos - larger_segment_rows) // base_size)
                )
                .otherwise(code_pos)
            )
            .cast(pl.Int64)
        )

        return segment_id_expr

    def _build_length_segment_id_expr(self, lengths: tuple[int, ...]) -> pl.Expr:
        code_pos = pl.col(self._code_pos_name)
        cumulative = 0
        segment_id_expr: pl.Expr | None = None

        for index, length in enumerate(lengths):
            cumulative += length
            if segment_id_expr is None:
                segment_id_expr = pl.when(code_pos < cumulative).then(index)
            else:
                segment_id_expr = segment_id_expr.when(code_pos < cumulative).then(index)

        if segment_id_expr is None:
            raise ExecutionError("Internal error: empty length segment specification")

        return segment_id_expr.otherwise(len(lengths) - 1).cast(pl.Int64)

    def _ensure_segment_lengths_cover_groups(
        self,
        prepared_df: pl.DataFrame,
        lengths: tuple[int, ...],
    ) -> None:
        total_length = sum(lengths)
        uncovered = prepared_df.filter(pl.col(self._code_len_name) > total_length).head(1)
        if uncovered.height > 0:
            raise ExecutionError("segment lengths do not cover full group")
