# 因子表达式引擎文档索引

这是 Factor Engine 的文档导航页，用来说明每份文档的职责边界，以及建议的阅读顺序。

## 文档分工

### 1. [README.md](../README.md)

适合谁看：

- 第一次接触项目的人
- 只想知道项目当前能做什么的人
- 想快速安装、运行、试用的人

回答的问题：

- 项目现在是什么
- 怎么安装和使用
- 当前能做什么
- 去哪里找完整语义

### 2. [language.md](language.md)

适合谁看：

- 需要确认 DSL 语法、运算符优先级和 null 规则的人
- 写复杂表达式时不想猜解析顺序的人

回答的问题：

- 当前 DSL 支持哪些表达式类型
- 运算符如何结合
- 逻辑与 null 怎么算

### 3. [functions.md](functions.md)

适合谁看：

- 需要查完整函数语义的人
- 需要确认 edge case、参数约束和最小示例的人

回答的问题：

- 每个函数做什么
- 参数和返回类型是什么
- 当前 edge case 是什么

### 4. [workflow.md](workflow.md)

适合谁看：

- 想从文件批量跑表达式的人
- 需要 parquet / csv 输出或 continue-on-error 行为的人

回答的问题：

- YAML / JSON schema 长什么样
- 严格模式和汇总模式怎么用
- 结果怎么写出

### 5. [errors.md](errors.md)

适合谁看：

- 想知道错误会在哪一层抛出的人
- 需要理解 batch failure report 格式的人

回答的问题：

- 当前有哪些错误类型
- stage 是怎么分类的
- `ExpressionFailure` / `BatchEvaluationReport` 长什么样

### 6. [design.md](design.md)

适合谁看：

- 需要理解当前代码结构和模块边界的人
- 准备新增函数、修改解析器 / 校验器 / 执行器的人

回答的问题：

- 当前系统怎么组织
- 核心抽象有哪些
- 模块之间怎么分工
- 新功能和 workflow helper 应该沿着什么扩展路径接入

### 7. [execution_planning_optimization.md](execution_planning_optimization.md)

适合谁看：

- 需要理解执行规划、批量执行和缓存复用的人
- 准备优化 `evaluate_many()`、`ExecutionProfile`、有序执行路径的人

回答的问题：

- 执行画像怎么推导
- 执行器如何按需求分流
- `evaluate_many()` 如何共享执行壳
- 当前执行规划有哪些边界

### 8. [revolution.md](revolution.md)

适合谁看：

- 想理解系统为什么演进成现在这样的人
- 需要查历史决策、阶段目标和复杂度分析的人

回答的问题：

- 过去做过哪些系统级变更
- 每次变更的背景、目标、任务、验收、风险、非目标是什么
- 理论复杂度、当前复杂度、未达到原因和未来建议是什么

### 9. [benchmark.md](benchmark.md)

适合谁看：

- 准备做阶段验收、性能对比或热点决策的人

回答的问题：

- benchmark 用什么口径
- benchmark 结果应该记录到哪里
- 冷缓存 / 热缓存与 `evaluate_many()` 对照怎么定义

### 10. [documentation_policy.md](documentation_policy.md)

适合谁看：

- 想知道文档什么时候该停、什么时候值得再次优化的人
- 准备改动文档或讨论功能是否要继续优化的人

回答的问题：

- 文档体系什么时候停止继续优化
- 再次优化的必要条件是什么
- 每类功能和模块的再次优化门槛是什么

## 推荐阅读顺序

### 路线 A：第一次了解项目

1. 先看 [README.md](../README.md)
2. 再看 [language.md](language.md) 和 [functions.md](functions.md)
3. 如果关心代码结构，再看 [design.md](design.md)
4. 如果关心历史与演进，再看 [revolution.md](revolution.md)

### 路线 B：准备改代码

1. 先看 [README.md](../README.md)
2. 再看 [language.md](language.md) 和 [functions.md](functions.md)
3. 再看 [design.md](design.md)
4. 如果改动涉及执行路径，再看 [execution_planning_optimization.md](execution_planning_optimization.md)
5. 如果要理解为什么当初这样设计，再看 [revolution.md](revolution.md)
6. 如果要决定文档或功能是否继续优化，再看 [documentation_policy.md](documentation_policy.md)

### 路线 D：准备跑研究工作流

1. 先看 [README.md](../README.md)
2. 再看 [workflow.md](workflow.md)
3. 如果需要错误格式，再看 [errors.md](errors.md)
4. 如果要理解为什么 grouped semantics / file workflow / error aggregation 这样落地，再看 [revolution.md](revolution.md)

### 路线 C：准备做性能优化

1. 先看 [execution_planning_optimization.md](execution_planning_optimization.md)
2. 再看 [benchmark.md](benchmark.md)
3. 再看 [revolution.md](revolution.md)
4. 最后回到 [design.md](design.md) 看当前代码结构落点

## 维护规则

- `README` 只维护当前真相，不承担历史演进记录
- `language` 只维护 DSL 语法、运算符与通用 null 语义
- `functions` 只维护函数级语义和 edge case
- `workflow` 只维护文件批次、输出写出和 continue-on-error 工作流
- `errors` 只维护错误类型、错误阶段和失败载荷
- `design` 只维护当前设计，不回放完整历史过程
- `execution_planning_optimization` 只维护执行规划专题，不承担总设计职责
- `revolution` 负责系统级历史演进，优先追加记录，不轻易抹平旧判断
- `benchmark` 负责 benchmark 口径与结果落点，不把性能记录散落到别处
- `documentation_policy` 负责定义“什么时候停”和“什么时候值得再次优化”
- 不把同一条语义细节同时写进 `README`、`design` 和专项文档

## 一句话索引

- 想知道“现在怎么用”：看 [README.md](../README.md)
- 想知道“表达式怎么解析”：看 [language.md](language.md)
- 想知道“每个函数到底怎么定义”：看 [functions.md](functions.md)
- 想知道“怎么从文件批量跑并拿到失败摘要”：看 [workflow.md](workflow.md) 和 [errors.md](errors.md)
- 想知道“现在怎么设计”：看 [design.md](design.md)
- 想知道“现在怎么执行”：看 [execution_planning_optimization.md](execution_planning_optimization.md)
- 想知道“为什么会变成这样”：看 [revolution.md](revolution.md)
- 想知道“什么时候该停、什么时候再优化”：看 [documentation_policy.md](documentation_policy.md)
