import polars as pl
import pytest

from factor_engine.engine import FactorEngine
from factor_engine.errors import ExecutionError


def test_engine_evaluate_corr():
    df = pl.DataFrame(
        {
            "time": [1, 1, 2, 2, 3, 3, 4, 4],
            "code": ["A", "B", "A", "B", "A", "B", "A", "B"],
            "close": [1.0, 10.0, 2.0, 20.0, 3.0, 30.0, 4.0, 40.0],
            "volume": [2.0, 8.0, 4.0, 6.0, 6.0, 4.0, 8.0, 2.0],
        }
    )

    result = FactorEngine().evaluate("corr(close, volume, 3)", df)
    values = result["result"].to_list()
    expected = [None, None, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0]

    for actual, target in zip(values, expected, strict=True):
        if target is None:
            assert actual is None
        else:
            assert actual == pytest.approx(target)


def test_corr_requires_window_at_least_two():
    df = pl.DataFrame(
        {
            "time": [1, 2],
            "code": ["A", "A"],
            "close": [1.0, 2.0],
            "volume": [2.0, 4.0],
        }
    )

    with pytest.raises(ExecutionError, match="window >= 2"):
        FactorEngine().evaluate("corr(close, volume, 1)", df)
