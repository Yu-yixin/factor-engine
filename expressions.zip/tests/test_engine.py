import polars as pl
import pytest

from factor_engine.executor import Executor
from factor_engine.errors import ArgumentError
from factor_engine.engine import FactorEngine
from factor_engine.lexer import Lexer
from factor_engine.validator import Validator


def test_engine_evaluate_delay():
    df = pl.DataFrame(
        {
            "time": [1, 2, 3],
            "code": ["A", "A", "A"],
            "close": [10.0, 20.0, 30.0],
        }
    )

    engine = FactorEngine()
    result = engine.evaluate("delay(close, 1)", df)

    assert result["result"].to_list() == [None, 10.0, 20.0]


def test_engine_evaluate_rank():
    df = pl.DataFrame(
        {
            "time": [1, 1, 1],
            "code": ["A", "B", "C"],
            "close": [10.0, 30.0, 20.0],
        }
    )

    engine = FactorEngine()
    result = engine.evaluate("rank(close, pct=true)", df)

    assert result["result"].to_list() == [1.0, 1 / 3, 2 / 3]


def test_engine_evaluate_many_with_logical_and_null_functions():
    df = pl.DataFrame(
        {
            "close": [1.0, None, 3.0],
            "open": [0.0, 2.0, 1.0],
            "flag": [True, None, False],
        }
    )

    result = FactorEngine().evaluate_many(
        [
            ("missing_close", "is_null(close)"),
            ("safe_flag", "fill_null(flag, false)"),
            ("usable", "not is_null(close) and fill_null(flag, false)"),
        ],
        df,
    )

    assert result["missing_close"].to_list() == [False, True, False]
    assert result["safe_flag"].to_list() == [True, False, False]
    assert result["usable"].to_list() == [True, False, False]


def test_engine_evaluate_many_returns_original_frame_plus_result_columns():
    df = pl.DataFrame(
        {
            "time": [2, 1, 1],
            "code": ["A", "A", "B"],
            "close": [20.0, 10.0, 100.0],
            "open": [18.0, 9.0, 90.0],
        }
    )

    engine = FactorEngine()
    result = engine.evaluate_many(
        [
            ("lagged", "delay(close, 1)"),
            ("spread", "close - open"),
            ("demeaned", "demean(close)"),
        ],
        df,
    )

    assert result.columns == ["time", "code", "close", "open", "lagged", "spread", "demeaned"]
    assert result["spread"].to_list() == [2.0, 1.0, 10.0]
    assert result["lagged"].to_list() == [10.0, None, None]


def test_engine_evaluate_many_rejects_duplicate_output_names():
    df = pl.DataFrame({"close": [1.0]})

    with pytest.raises(ArgumentError, match="Duplicate output column name"):
        FactorEngine().evaluate_many([("x", "close"), ("x", "close + 1")], df)


def test_engine_evaluate_many_rejects_table_expressions():
    df = pl.DataFrame(
        {
            "time": [1, 2],
            "code": ["A", "A"],
            "close": [1.0, 2.0],
        }
    )

    with pytest.raises(ArgumentError, match="only supports column expressions"):
        FactorEngine().evaluate_many([("spec", "fft(close)")], df)


def test_engine_reuses_cached_parse_validate_and_compile(
    monkeypatch: pytest.MonkeyPatch,
):
    df = pl.DataFrame(
        {
            "time": [1, 2],
            "code": ["A", "A"],
            "close": [10.0, 20.0],
            "open": [8.0, 18.0],
        }
    )
    counts = {"tokenize": 0, "validate": 0, "compile": 0}

    original_tokenize = Lexer.tokenize
    original_validate = Validator.validate
    original_compile = Executor.compile

    def track_tokenize(self):
        counts["tokenize"] += 1
        return original_tokenize(self)

    def track_validate(self, expr):
        counts["validate"] += 1
        return original_validate(self, expr)

    def track_compile(self, expr):
        counts["compile"] += 1
        return original_compile(self, expr)

    monkeypatch.setattr(Lexer, "tokenize", track_tokenize)
    monkeypatch.setattr(Validator, "validate", track_validate)
    monkeypatch.setattr(Executor, "compile", track_compile)

    engine = FactorEngine()
    first = engine.evaluate("close - open", df)
    second = engine.evaluate("close - open", df)

    assert first["result"].to_list() == [2.0, 2.0]
    assert second["result"].to_list() == [2.0, 2.0]
    assert counts == {"tokenize": 1, "validate": 1, "compile": 1}


def test_engine_evaluate_many_reuses_compiled_expression_once(
    monkeypatch: pytest.MonkeyPatch,
):
    df = pl.DataFrame(
        {
            "time": [1, 2],
            "code": ["A", "A"],
            "close": [10.0, 20.0],
            "open": [8.0, 18.0],
        }
    )
    counts = {"compile": 0}
    original_compile = Executor.compile

    def track_compile(self, expr):
        counts["compile"] += 1
        return original_compile(self, expr)

    monkeypatch.setattr(Executor, "compile", track_compile)

    result = FactorEngine().evaluate_many(
        [
            ("spread_a", "close - open"),
            ("spread_b", "close - open"),
        ],
        df,
    )

    assert result["spread_a"].to_list() == [2.0, 2.0]
    assert result["spread_b"].to_list() == [2.0, 2.0]
    assert counts["compile"] == 1


def test_engine_cache_is_invalidated_by_schema_changes(
    monkeypatch: pytest.MonkeyPatch,
):
    base_df = pl.DataFrame(
        {
            "time": [1, 2],
            "code": ["A", "A"],
            "close": [10.0, 20.0],
            "open": [8.0, 18.0],
        }
    )
    widened_df = base_df.with_columns(pl.lit(1.0).alias("volume"))
    counts = {"tokenize": 0, "validate": 0, "compile": 0}

    original_tokenize = Lexer.tokenize
    original_validate = Validator.validate
    original_compile = Executor.compile

    def track_tokenize(self):
        counts["tokenize"] += 1
        return original_tokenize(self)

    def track_validate(self, expr):
        counts["validate"] += 1
        return original_validate(self, expr)

    def track_compile(self, expr):
        counts["compile"] += 1
        return original_compile(self, expr)

    monkeypatch.setattr(Lexer, "tokenize", track_tokenize)
    monkeypatch.setattr(Validator, "validate", track_validate)
    monkeypatch.setattr(Executor, "compile", track_compile)

    engine = FactorEngine()
    engine.evaluate("close - open", base_df)
    engine.evaluate("close - open", widened_df)

    assert counts == {"tokenize": 1, "validate": 2, "compile": 2}


def test_engine_cache_preserves_validation_errors(
    monkeypatch: pytest.MonkeyPatch,
):
    df = pl.DataFrame(
        {
            "time": [1, 2],
            "code": ["A", "A"],
            "label": ["x", "y"],
        }
    )
    counts = {"validate": 0}
    original_validate = Validator.validate

    def track_validate(self, expr):
        counts["validate"] += 1
        return original_validate(self, expr)

    monkeypatch.setattr(Validator, "validate", track_validate)

    engine = FactorEngine()

    with pytest.raises(ArgumentError, match="numeric input column"):
        engine.evaluate("ts_rank(label, 2)", df)

    with pytest.raises(ArgumentError, match="numeric input column"):
        engine.evaluate("ts_rank(label, 2)", df)

    assert counts["validate"] == 2
