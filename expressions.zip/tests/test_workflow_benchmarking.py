from __future__ import annotations

import polars as pl

from factor_engine.engine import FactorEngine
from factor_engine.workflow import BatchExpression, evaluate_expression_batch_report


class CountingEngine(FactorEngine):
    def __init__(self) -> None:
        super().__init__()
        self.evaluate_calls: list[str] = []
        self.evaluate_many_calls: int = 0

    def evaluate(self, expression: str, df: pl.DataFrame, output_name: str = "result") -> pl.DataFrame:
        self.evaluate_calls.append(expression)
        return super().evaluate(expression, df, output_name=output_name)

    def evaluate_many(
        self,
        expressions: list[tuple[str, str]],
        df: pl.DataFrame,
    ) -> pl.DataFrame:
        self.evaluate_many_calls += 1
        return super().evaluate_many(expressions, df)


def build_df() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "time": [1, 2, 3],
            "code": ["A", "A", "A"],
            "close": [10.0, 15.0, 12.0],
            "open": [9.0, 11.0, 11.0],
            "industry": ["tech", "tech", "tech"],
        }
    )


def test_batch_report_uses_evaluate_many_fast_path_for_all_valid_expressions():
    engine = CountingEngine()

    report = evaluate_expression_batch_report(
        [
            BatchExpression(name="spread", expression="close - open"),
            BatchExpression(name="lagged", expression="delay(close, 1)"),
        ],
        build_df(),
        engine=engine,
    )

    assert [item.name for item in report.successes] == ["spread", "lagged"]
    assert report.failures == []
    assert engine.evaluate_many_calls == 1
    assert engine.evaluate_calls == []
