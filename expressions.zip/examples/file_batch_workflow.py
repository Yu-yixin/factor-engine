from __future__ import annotations

import argparse

import polars as pl

from factor_engine.workflow import evaluate_expression_file, evaluate_expression_file_report, write_result


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a batch expression file against an input parquet.")
    parser.add_argument("input", help="Input parquet path")
    parser.add_argument("expressions", help="Expression batch file (.json/.yaml/.yml)")
    parser.add_argument("--output", help="Optional output path (.parquet/.csv)")
    parser.add_argument(
        "--continue-on-error",
        action="store_true",
        help="Keep successful expressions and print a structured failure summary.",
    )
    args = parser.parse_args()

    df = pl.read_parquet(args.input)
    if args.continue_on_error:
        report = evaluate_expression_file_report(args.expressions, df)
        result = report.result_df
        for failure in report.failures:
            print(
                f"[{failure.stage}] {failure.error_type}"
                f" name={failure.name!r} expression={failure.expression!r}: {failure.message}"
            )
    else:
        result = evaluate_expression_file(args.expressions, df)

    if args.output:
        write_result(result, args.output)
    else:
        print(result)


if __name__ == "__main__":
    main()
